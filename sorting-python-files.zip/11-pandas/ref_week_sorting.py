import pandas as pd

df = pd.read_excel("./python/11-pandas/Over70-HH-distribution.xlsx")
print(df.head())